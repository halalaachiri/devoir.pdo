
<?php

require_once "connection.php";

// 1. Vérifier si l'identifiant est envoyé
if (!isset($_POST['id']) || !ctype_digit($_POST['id'])) {
    die("Identifiant invalide");
}

// 2. Récupérer l'identifiant
$id = (int) $_POST['id'];

// 3. Supprimer l'exercice
$sql = "DELETE FROM exercice WHERE id = ?";

$stmt = $pdo->prepare($sql);

$stmt->execute([$id]);

// 4. Retourner à la liste des exercices
header("Location: index.php");
exit();

?>
