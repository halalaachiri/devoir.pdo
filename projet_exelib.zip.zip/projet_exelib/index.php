
<?php

require_once "connection.php";

// 1. Ajouter un exercice
if (isset($_POST['ajouter'])) {

    $titre = $_POST['titre'];
    $auteur = $_POST['auteur'];
    $date_creation = $_POST['date_creation'];

    $sql = "INSERT INTO exercice (titre, auteur, date_creation)
            VALUES (?, ?, ?)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$titre, $auteur, $date_creation]);

    header("Location: index.php");
    exit();
}

// 2. Afficher les exercices
$sql = "SELECT * FROM exercice ORDER BY id ASC";

$stmt = $pdo->query($sql);

$exercices = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Gestion des exercices</title>
</head>

<body>

    <h1>Gestion des exercices</h1>

    <!-- Formulaire d'ajout -->

    <h2>Ajouter un exercice</h2>

    <form method="POST" action="index.php">

        <label>Titre :</label>
        <input type="text" name="titre" required>
        <br><br>

        <label>Auteur :</label>
        <input type="text" name="auteur" required>
        <br><br>

        <label>Date de création :</label>
        <input type="date" name="date_creation" required>
        <br><br>

        <button type="submit" name="ajouter">
            Ajouter
        </button>

    </form>

    <!-- Tableau d'affichage -->

    <h2>Liste des exercices</h2>

    <table border="1" cellpadding="10">

        <tr>
            <th>ID</th>
            <th>Titre</th>
            <th>Auteur</th>
            <th>Date de création</th>
            <th>Actions</th>
        </tr>

        <?php foreach ($exercices as $ex): ?>

        <tr>

            <td><?= htmlspecialchars($ex['id']) ?></td>

            <td><?= htmlspecialchars($ex['titre']) ?></td>

            <td><?= htmlspecialchars($ex['auteur']) ?></td>

            <td><?= htmlspecialchars($ex['date_creation']) ?></td>

            <td>

                <!-- Bouton Modifier -->

                <a href="modif_ex.php?id=<?= $ex['id'] ?>">
                    Modifier
                </a>

                |

                <!-- Bouton Supprimer -->

                <form method="POST"
                      action="supp_ex.php"
                      style="display:inline;"
                      onsubmit="return confirm('Voulez-vous supprimer cet exercice ?');">

                    <input type="hidden" name="id"
                           value="<?= $ex['id'] ?>">

                    <button type="submit">
                        Supprimer
                    </button>

                </form>

            </td>

        </tr>

        <?php endforeach; ?>

    </table>

</body>
</html>
