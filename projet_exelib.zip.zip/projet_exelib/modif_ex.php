
<?php

require_once "connection.php";

// 1. Vérifier si l'identifiant existe dans l'URL
if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    die("Identifiant invalide");
}

$id = (int) $_GET['id'];

// 2. Récupérer les informations de l'exercice
$sql = "SELECT * FROM exercice WHERE id = ?";

$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);

$exercice = $stmt->fetch(PDO::FETCH_ASSOC);

// Vérifier si l'exercice existe
if (!$exercice) {
    die("Exercice introuvable");
}

// 3. Modifier les informations
if (isset($_POST['modifier'])) {

    $titre = $_POST['titre'];
    $auteur = $_POST['auteur'];
    $date_creation = $_POST['date_creation'];

    $sql = "UPDATE exercice
            SET titre = ?, auteur = ?, date_creation = ?
            WHERE id = ?";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([$titre, $auteur, $date_creation, $id]);

    header("Location: index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Modifier un exercice</title>
</head>

<body>

    <h1>Modifier un exercice</h1>

    <form method="POST">

        <label>Titre :</label>
        <input type="text" name="titre"
               value="<?= htmlspecialchars($exercice['titre']) ?>"
               required>
        <br><br>

        <label>Auteur :</label>
        <input type="text" name="auteur"
               value="<?= htmlspecialchars($exercice['auteur']) ?>"
               required>
        <br><br>

        <label>Date de création :</label>
        <input type="date" name="date_creation"
               value="<?= htmlspecialchars($exercice['date_creation']) ?>"
               required>
        <br><br>

        <button type="submit" name="modifier">
            Enregistrer les modifications
        </button>

    </form>

    <br>

    <a href="index.php">Retour à la liste</a>

</body>
</html>
