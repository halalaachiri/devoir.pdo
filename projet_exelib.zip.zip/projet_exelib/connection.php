<?php

$host = "localhost";
$dbname = "exelib";
$username = "root";
$password = "";

try {

    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password
    );

    echo "Connexion réussie !";

} catch (PDOException $e) {

    die("Erreur : " . $e->getMessage());

}

?>